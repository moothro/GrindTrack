//
//  LoginView.swift
//  GrindTrack
//
//  Created by Cletus Hyacinth on 4/23/25.
//
import SwiftUI

struct LoginView: View {
    @State private var email = ""
    @State private var password = ""
    @AppStorage("isLoggedIn") private var isLoggedIn = false
    var onLoginSuccess: (() -> Void)? = nil  // Optional closure for transitions

    var body: some View {
        VStack(spacing: 20) {
            Text("🔒 GrindTrack Login")
                .font(.largeTitle)
                .fontWeight(.bold)

            TextField("Email", text: $email)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .keyboardType(.emailAddress)
                .autocapitalization(.none)

            SecureField("Password", text: $password)
                .textFieldStyle(RoundedBorderTextFieldStyle())

            Button("Log In") {
                if !email.isEmpty && !password.isEmpty {
                    isLoggedIn = true
                    onLoginSuccess?()
                }
            }
            .font(.headline)
            .foregroundColor(.white)
            .padding()
            .frame(maxWidth: .infinity)
            .background(Color.accentColor)
            .cornerRadius(10)

            Spacer()
        }
        .padding()
    }
}

#Preview {
    LoginView {
        print("Login successful — Preview Mode")
    }
}

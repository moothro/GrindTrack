//
//  AppScreen.swift
//  GrindTrack
//
//  Created by Cletus Hyacinth on 4/23/25.
//
import Foundation

enum AppScreen {
    case login
    case loading
    case home
}

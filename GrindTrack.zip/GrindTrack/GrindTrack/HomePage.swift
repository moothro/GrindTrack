//
//  HomePage.swift
//  GrindTrack
//
//  Created by Cletus Hyacinth on 4/7/25.
//
import SwiftUI

struct Workout: Identifiable, Codable {
    var id = UUID()
    var date: Date
    var title: String
    var exercises: [String]
}

struct HomeView: View {
    @State private var workouts: [Workout] = [
        Workout(date: Date(), title: "Upper Body", exercises: ["Push-ups", "Pull-ups", "Bench Press"]),
        Workout(date: Calendar.current.date(byAdding: .day, value: -1, to: Date())!, title: "Leg Day", exercises: ["Squats", "Lunges", "Deadlifts"])
    ]

    var body: some View {
        NavigationStack {
            VStack(spacing: 20) {
                HStack {
                    Text("🏋️‍♂️ GrindTrack")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                    Spacer()
                    NavigationLink(destination: AddWorkoutView()) {
                        Image(systemName: "plus.circle.fill")
                            .font(.system(size: 30))
                            .foregroundColor(.accentColor)
                    }
                }
                .padding(.horizontal)
               
                HStack {
                    NavigationLink(destination: WorkoutLogView(workouts: workouts)) {
                        Label("Workout Log", systemImage: "book.fill")
                            .font(.subheadline)
                            .padding(.vertical, 6)
                            .padding(.horizontal, 12)
                            .background(Color.accentColor.opacity(0.1))
                            .foregroundColor(.accentColor)
                            .cornerRadius(10)
                    }
                    Spacer()
                }
                .padding(.horizontal)

                ScrollView {
                    VStack(spacing: 16) {
                        ForEach(workouts) { workout in
                            NavigationLink(destination: WorkoutDetailView(workout: workout)) {
                                VStack(alignment: .leading, spacing: 8) {
                                    Text(workout.title)
                                        .font(.headline)
                                        .foregroundColor(.primary)

                                    Text(formattedDate(workout.date))
                                        .font(.subheadline)
                                        .foregroundColor(.secondary)

                                    HStack(spacing: 6) {
                                        ForEach(workout.exercises.prefix(3), id: \.self) { exercise in
                                            Text(exercise)
                                                .font(.caption)
                                                .padding(.horizontal, 8)
                                                .padding(.vertical, 4)
                                                .background(Color.accentColor.opacity(0.2))
                                                .cornerRadius(8)
                                        }
                                    }
                                }
                                .padding()
                                .background(Color(.systemGray6))
                                .cornerRadius(16)
                                .shadow(color: .black.opacity(0.05), radius: 5, x: 0, y: 2)
                            }
                            .buttonStyle(PlainButtonStyle())
                        }
                    }
                    .padding(.horizontal)
                }
            }
            .navigationTitle("")
            .navigationBarHidden(true)
        }
    }

    func formattedDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        return formatter.string(from: date)
    }
}

struct WorkoutDetailView: View {
    let workout: Workout

    var body: some View {
        List {
            Section(header: Text("Exercises")) {
                ForEach(workout.exercises, id: \.self) { exercise in
                    Text(exercise)
                }
            }
        }
        .navigationTitle(workout.title)
    }
}

struct AddWorkoutView: View {
    var body: some View {
        Text("Add Workout View")
            .navigationTitle("New Workout")
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}

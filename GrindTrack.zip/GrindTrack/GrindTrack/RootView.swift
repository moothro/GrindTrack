//
//  RootView.swift
//  GrindTrack
//
//  Created by Cletus Hyacinth on 4/14/25.
//

import SwiftUI

struct RootView: View {
    @AppStorage("isLoggedIn") private var isLoggedIn = false
    @State private var isLoading = true

    // Sample workouts to pass through the app
    @State private var workouts: [Workout] = [
        Workout(date: Date(), title: "Upper Body", exercises: ["Push-ups", "Pull-ups", "Bench Press"]),
        Workout(date: Calendar.current.date(byAdding: .day, value: -1, to: Date())!, title: "Leg Day", exercises: ["Squats", "Lunges", "Deadlifts"])
    ]

    var body: some View {
        Group {
            if isLoading {
                LoadingScreen(workouts: workouts)
                    .onAppear {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                            isLoading = false
                        }
                    }
            } else {
                if isLoggedIn {
                    HomeView()
                } else {
                    LoginView()
                }
            }
        }
    }
}

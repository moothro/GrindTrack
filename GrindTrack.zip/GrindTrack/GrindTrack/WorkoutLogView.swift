//
//  WorkoutLogView.swift
//  GrindTrack
//
//  Created by Cletus Hyacinth on 4/10/25.
//
import SwiftUI

struct WorkoutLogView: View {
    let workouts: [Workout]

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                Text("📓 Workout Log")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .padding(.top)

                ForEach(workouts.sorted(by: { $0.date > $1.date })) { workout in
                    VStack(alignment: .leading, spacing: 10) {
                        HStack {
                            VStack(alignment: .leading, spacing: 4) {
                                Text(workout.title)
                                    .font(.headline)
                                    .foregroundColor(.primary)
                                Text(formattedDate(workout.date))
                                    .font(.subheadline)
                                    .foregroundColor(.secondary)
                            }
                            Spacer()
                            Image(systemName: "calendar")
                                .foregroundColor(.accentColor)
                        }

                        Divider()

                        VStack(alignment: .leading, spacing: 6) {
                            ForEach(workout.exercises, id: \.self) { exercise in
                                HStack {
                                    Image(systemName: "dumbbell.fill")
                                        .foregroundColor(.accentColor)
                                    Text(exercise)
                                        .font(.body)
                                }
                            }
                        }
                    }
                    .padding()
                    .background(Color(.systemBackground))
                    .cornerRadius(16)
                    .shadow(color: .black.opacity(0.05), radius: 5, x: 0, y: 2)
                }

                Spacer(minLength: 50)
            }
            .padding(.horizontal)
        }
        .background(Color(.systemGroupedBackground).edgesIgnoringSafeArea(.all))
    }

    func formattedDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .full
        return formatter.string(from: date)
    }
}

struct WorkoutLogView_Previews: PreviewProvider {
    static var previews: some View {
        WorkoutLogView(workouts: [
            Workout(date: Date(), title: "Upper Body", exercises: ["Push-ups", "Pull-ups", "Bench Press"]),
            Workout(date: Calendar.current.date(byAdding: .day, value: -2, to: Date())!, title: "Cardio", exercises: ["Running", "Cycling", "Jump Rope"]),
            Workout(date: Calendar.current.date(byAdding: .day, value: -5, to: Date())!, title: "Leg Day", exercises: ["Squats", "Lunges", "Deadlifts"])
        ])
    }
}

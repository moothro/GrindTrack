//
//  WorkoutLogView.swift
//  GrindTrack
//
//  Created by Cletus Hyacinth on 4/10/25.
//
import SwiftUI

struct WorkoutLogView: View {
    let workouts: [Workout]
    
    @State private var selectedDate: Date? = nil
    @State private var showCalendar: Bool = false

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                Text("📓 Workout Log")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .padding(.top)

                // Toggle Calendar Button
                Button(action: {
                    withAnimation {
                        showCalendar.toggle()
                    }
                }) {
                    HStack {
                        Image(systemName: "calendar")
                        Text(showCalendar ? "Hide Calendar" : "Show Calendar")
                    }
                    .padding(.vertical, 8)
                    .padding(.horizontal)
                    .background(Color.accentColor.opacity(0.1))
                    .cornerRadius(12)
                }

                // Calendar Grid
                if showCalendar {
                    VStack(alignment: .leading) {
                        Text("📅 Select a Date")
                            .font(.title2)
                            .fontWeight(.semibold)
                            .padding(.top)

                        let gridItems = Array(repeating: GridItem(.flexible()), count: 7)
                        let startDate = Calendar.current.date(byAdding: .day, value: -30, to: Date())!
                        let dates = (0..<31).map { Calendar.current.date(byAdding: .day, value: $0, to: startDate)! }

                        LazyVGrid(columns: gridItems, spacing: 10) {
                            ForEach(dates, id: \.self) { currentDate in
                                let day = Calendar.current.component(.day, from: currentDate)

                                Button(action: {
                                    selectedDate = currentDate
                                }) {
                                    Text("\(day)")
                                        .frame(width: 30, height: 30)
                                        .background(
                                            selectedDate != nil && Calendar.current.isDate(selectedDate!, inSameDayAs: currentDate)
                                                ? Color.accentColor
                                                : Color.gray.opacity(0.2)
                                        )
                                        .foregroundColor(
                                            selectedDate != nil && Calendar.current.isDate(selectedDate!, inSameDayAs: currentDate)
                                                ? .white
                                                : .primary
                                        )
                                        .cornerRadius(15)
                                }
                                .buttonStyle(PlainButtonStyle())
                            }
                        }
                        .padding(.bottom)
                    }
                }

                // Workout Display
                if let selectedDate = selectedDate {
                    if let workout = workouts.first(where: { Calendar.current.isDate($0.date, inSameDayAs: selectedDate) }) {
                        VStack(alignment: .leading, spacing: 10) {
                            Text(workout.title)
                                .font(.headline)
                            Text(formattedDate(workout.date))
                                .font(.subheadline)
                                .foregroundColor(.secondary)

                            Divider()

                            VStack(alignment: .leading, spacing: 6) {
                                ForEach(workout.exercises, id: \.self) { exercise in
                                    HStack {
                                        Image(systemName: "dumbbell.fill")
                                            .foregroundColor(.accentColor)
                                        Text(exercise)
                                    }
                                }
                            }
                        }
                        .padding()
                        .background(Color(.systemBackground))
                        .cornerRadius(16)
                        .shadow(color: .black.opacity(0.05), radius: 5, x: 0, y: 2)
                    } else {
                        Text("No workout found for this day.")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }
                }

                Spacer(minLength: 50)
            }
            .padding(.horizontal)
        }
        .background(Color(.systemGroupedBackground).edgesIgnoringSafeArea(.all))
    }

    func formattedDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .full
        return formatter.string(from: date)
    }
}

// MARK: - Preview
struct WorkoutLogView_Previews: PreviewProvider {
    static var previews: some View {
        let previewWorkouts = [
            Workout(date: Date(), title: "Upper Body", exercises: ["Push-ups", "Pull-ups", "Bench Press"]),
            Workout(date: Calendar.current.date(byAdding: .day, value: -2, to: Date())!, title: "Cardio", exercises: ["Running", "Cycling", "Jump Rope"]),
            Workout(date: Calendar.current.date(byAdding: .day, value: -5, to: Date())!, title: "Leg Day", exercises: ["Squats", "Lunges", "Deadlifts"])
        ]

        return WorkoutLogView(workouts: previewWorkouts)
    }
}

// Workout model


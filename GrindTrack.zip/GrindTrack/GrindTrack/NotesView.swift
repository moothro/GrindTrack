//
//  NotesView.swift
//  GrindTrack
//
//  Created by Cletus Hyacinth on 4/25/25.
//
import SwiftUI

struct NotesView: View {
    @AppStorage("userNotes") private var userNotes: String = ""

    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text("📝 Workout Notes")
                .font(.largeTitle)
                .fontWeight(.bold)

            TextEditor(text: $userNotes)
                .padding()
                .background(Color(.systemGray6))
                .cornerRadius(10)
                .frame(minHeight: 300)

            Spacer()
        }
        .padding()
        .navigationTitle("Notes")
    }
}
#Preview {
    NavigationView {
        NotesView()
    }
}

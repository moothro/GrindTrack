//
//  SettingsView.swift
//  GrindTrack
//
//  Created by Cletus Hyacinth on 4/18/25.
//
import SwiftUI

struct SettingsView: View {
    @AppStorage("fitnessGoal") private var fitnessGoal = "Lose Weight"
    @AppStorage("notificationsEnabled") private var notificationsEnabled = true
    @AppStorage("darkMode") private var darkMode = false
    @AppStorage("units") private var units = "lbs"

    var body: some View {
        Form {
            Section(header: Text("Fitness Goal")) {
                Picker("Goal", selection: $fitnessGoal) {
                    Text("Lose Weight").tag("Lose Weight")
                    Text("Build Muscle").tag("Build Muscle")
                    Text("Stay Active").tag("Stay Active")
                }
                .pickerStyle(SegmentedPickerStyle())
            }

            Section(header: Text("Notifications")) {
                Toggle("Enable Notifications", isOn: $notificationsEnabled)
            }

            Section(header: Text("Display")) {
                Toggle("Dark Mode", isOn: $darkMode)
            }

            Section(header: Text("Units")) {
                Picker("Preferred Units", selection: $units) {
                    Text("Pounds (lbs)").tag("lbs")
                    Text("Kilograms (kg)").tag("kg")
                }
                .pickerStyle(SegmentedPickerStyle())
            }
        }
        .navigationTitle("Settings")
    }
}

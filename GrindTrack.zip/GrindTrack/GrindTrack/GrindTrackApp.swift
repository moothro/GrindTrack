//
//  GrindTrackApp.swift
//  GrindTrack
//
//  Created by Cletus Hyacinth on 4/7/25.
//

import SwiftUI

@main
struct GrindTrackApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

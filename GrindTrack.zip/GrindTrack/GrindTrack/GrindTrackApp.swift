//
//  GrindTrackApp.swift
//  GrindTrack
//
//  Created by Cletus Hyacinth on 4/7/25.
//
import SwiftUI

@main
struct GrindTrackApp: App {
   @AppStorage("darkMode") private var darkMode = false

   var body: some Scene {
       WindowGroup {
           HomeView()
               .preferredColorScheme(darkMode ? .dark : .light)
       }
   }
}

/*
import SwiftUI

@main
struct GrindTrackApp: App {
    @State private var currentScreen: AppScreen = .login

    var body: some Scene {
        WindowGroup {
            switch currentScreen {
            case .login:
                LoginView(onLoginSuccess: {
                    currentScreen = .loading
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                        currentScreen = .home
                    }
                })
            case .loading:
                LoadingScreen()
            case .home:
                HomeView()
            }
        }
    }
}*/


/*
@main
struct GrindTrackApp: App {
    @AppStorage("darkMode") private var darkMode = false
*/
